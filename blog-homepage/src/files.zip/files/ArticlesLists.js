import React, { Component } from 'react'
import Article from './Article'
import img1 from '../assets/logo512.png';
import img2 from '../assets/logo512.png';
import img3 from '../assets/logo512.png';
import missedArticles from './missed-articles'


class ArticleLists extends Component {
    constructor() {
        super();
        this.state = {
            missedArticles: missedArticles,
        };
    }
    render() {
        return (
            <div className="container-fluid d-flex justify-content-center">
                <div className="row">
                    <div className="col-md-4">
                        <Article imgsrc={this.state.missedArticles[0].image} title={this.state.missedArticles[0].title} />
                    </div>
                    <div className="col-md-4">
                        <Article imgsrc={this.state.missedArticles[1].image} title={this.state.missedArticles[1].title} />
                    </div>
                    <div className="col-md-4">
                        <Article imgsrc={this.state.missedArticles[2].image} title={this.state.missedArticles[2].title} />
                    </div>
                </div>
            </div>
        );
    }
}

export default ArticleLists;