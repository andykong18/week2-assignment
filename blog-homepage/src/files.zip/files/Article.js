import React from 'react';
import img1 from '../assets/logo512.png';

const Article = props => {
    return (
        <div className="article text-center">
            <div className="overflow">
                <img src={img1} alt ="image 1" />
            </div>
            <div className="article-body text-dark">
                <h4 className="article-title">article Title</h4>
                <p className="article-text text-secondary">
                Lorem ipsum dolor sit amet, et mei harum primis. 
                Mea numquam propriae id, dicit epicurei corrumpit sit no. 
                No pri.
                </p>
                <a href='#' className ="btn btn-outline-success">
                    Go Anywhere
                </a>
            </div>
        </div>
    );
};

export default Article;
